/*=========================================================================================
    File Name: const-plyr.js
    Description: Media Player
    --------------------------------------------------------------------------------------
    Item name: Vuexy  - Vuejs, HTML & Laravel Admin Dashboard Template
    Author: PIXINVENT
    Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/

// Media Player
const player = new Plyr('#player');