A dropdown of state and LGA in Nigeria.
A simple javaScript plugin to shows the dropdown of LGA based on a Selected State
<br><center><img src="img/eg.png"></center><br>

<b>HOW TO</b>
<ol>
<li>Add the lga.js script to your project</li>
<li> The state select filed should have an id of state <code>id="state"</code></li>
<li>The LGA Select Field should have an id of lga <code>id="lga"</code></li>

<b>Demo</a>
<a href="https://ekpangmichael.github.io/state-LGA-NG/" target="_blank">DEMO</a>

