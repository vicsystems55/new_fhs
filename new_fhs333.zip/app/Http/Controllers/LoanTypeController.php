<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LoanTypeController extends Controller
{
    //
}
