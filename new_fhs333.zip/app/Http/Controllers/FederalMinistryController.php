<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FederalMinistryController extends Controller
{
    //
}
