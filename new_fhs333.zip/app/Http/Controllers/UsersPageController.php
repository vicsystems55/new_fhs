<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\User;

use App\LoanType;

use App\PersonalInfo;

use App\FederalMinistry;

use App\Parastatal;

use App\DocumentUpload;

use Auth;

use Carbon\Carbon;

use App\LoanApplication;

use App\LoanCeiling;

class UsersPageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
        $pageConfigs = [
            'pageHeader' => true
        ];

        return view('pages.user-dashboard', [
            'pageConfigs' => $pageConfigs
        ]);
    }


    public function notifications(){
        $pageConfigs = [
            'pageHeader' => true
        ];

        return view('pages.user.notifications', [
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function profile(){
        $pageConfigs = [
            'pageHeader' => true
        ];
        
        $user_id = Auth::user()->id;

        $user_data = User::find($user_id);

        $fed_min = FederalMinistry::all();

        $parastatals = Parastatal::all();

        $personal_data = PersonalInfo::where('user_id', $user_id)->first();

       

        if($personal_data && $personal_data->bio_state =='done'){

            return view('pages.user.profile2_final', [
                'pageConfigs' => $pageConfigs,
                'fed_min' => $fed_min,
                'parastatals' => $parastatals,
                'personal_data' => $personal_data,
                'user_data' => $user_data
            ]);

        }else{

            return view('pages.user.profile2', [
                'pageConfigs' => $pageConfigs,
                'fed_min' => $fed_min,
                'parastatals' => $parastatals,
                'personal_data' => $personal_data,
                'user_data' => $user_data
            ]);

        }

          
    }

    public function profile2(){
        $pageConfigs = [
            'pageHeader' => true
        ];
        
        $user_id = Auth::user()->id;

        $user_data = User::find($user_id);

        $fed_min = FederalMinistry::all();

        $parastatals = Parastatal::all();

        $personal_data = PersonalInfo::where('user_id', $user_id)->first();

       

        if($personal_data && $personal_data->apoint_state =='done'){

            return view('pages.user.profile22_final', [
                'pageConfigs' => $pageConfigs,
                'fed_min' => $fed_min,
                'parastatals' => $parastatals,
                'personal_data' => $personal_data,
                'user_data' => $user_data
            ]);

        }else{

            return view('pages.user.profile22', [
                'pageConfigs' => $pageConfigs,
                'fed_min' => $fed_min,
                'parastatals' => $parastatals,
                'personal_data' => $personal_data,
                'user_data' => $user_data
            ]);

        }

          
    }

    public function ministry(Type $var = null)
    {
        # code...
        $pageConfigs = [
            'pageHeader' => true
        ];

        $user_id = Auth::user()->id;

        $user_data = User::find($user_id);

        $fed_min = FederalMinistry::all();

        $parastatals = Parastatal::all();

        $personal_data = PersonalInfo::where('user_id', $user_id)->update([
            'category'=> 'ministry'
        ]);

        $personal_data = PersonalInfo::where('user_id', $user_id)->first();

            if($personal_data->appoint_state =="done"){

                return view('pages.user.ministry_final', [
                    'pageConfigs' => $pageConfigs,
                    'fed_min' => $fed_min,
                    'parastatals' => $parastatals,
                    'personal_data' => $personal_data,
                    'user_data' => $user_data
                ]);

            }else{

                return view('pages.user.ministry', [
                    'pageConfigs' => $pageConfigs,
                    'fed_min' => $fed_min,
                    'parastatals' => $parastatals,
                    'personal_data' => $personal_data,
                    'user_data' => $user_data
                ]);

            }

        
    }

    public function military(Type $var = null)
    {
        # code...

        $pageConfigs = [
            'pageHeader' => true
        ];

        $user_id = Auth::user()->id;

        $user_data = User::find($user_id);

        $fed_min = FederalMinistry::all();

        $parastatals = Parastatal::all();

        $personal_data = PersonalInfo::where('user_id', $user_id)->update([
            'category'=> 'military'
        ]);

        $personal_data = PersonalInfo::where('user_id', $user_id)->first();


        if($personal_data->appoint_state =="done"){

            return view('pages.user.military_final', [
                'pageConfigs' => $pageConfigs,
                'fed_min' => $fed_min,
                'parastatals' => $parastatals,
                'personal_data' => $personal_data,
                'user_data' => $user_data
            ]);

        }else{

            return view('pages.user.military', [
                'pageConfigs' => $pageConfigs,
                'fed_min' => $fed_min,
                'parastatals' => $parastatals,
                'personal_data' => $personal_data,
                'user_data' => $user_data
            ]);

        }
    }

    


    public function profile3(){
        $pageConfigs = [
            'pageHeader' => true
        ];
        $user_id = Auth::user()->id;

        $fed_min = FederalMinistry::all();

        $parastatals = Parastatal::all();

        $user_doc = DocumentUpload::where('user_id', $user_id)->get();

        $user_passport = DocumentUpload::where('user_id', $user_id)->where('name', 'passport')->first();

        $user_ap_letter = DocumentUpload::where('user_id', $user_id)->where('name', 'appoint_letter')->first();

        

        

        $personal_data = PersonalInfo::where('user_id', $user_id)->first();

        $user_data = User::find($user_id);

       
        
        

        return view('pages.user.uploads_new', [
            'pageConfigs' => $pageConfigs,
            'fed_min' => $fed_min,
            'parastatals' => $parastatals,
            'user_doc' => $user_doc,
            'user_passport' => $user_passport,
            'user_ap_letter' => $user_ap_letter,
            'personal_data' => $personal_data,
            'user_data' => $user_data
        ]);
    }


    public function view_profile(){
        $pageConfigs = [
            'pageHeader' => true
        ];
        $user_id = Auth::user()->id;

        $personal_data = PersonalInfo::where('user_id', $user_id)->first();

        $user_doc = DocumentUpload::where('user_id', $user_id)->get();


        return view('pages.user.view_profile', [
            'pageConfigs' => $pageConfigs,

            'user_doc' => $user_doc,
            
            'personal_data' => $personal_data
        ]);
    }

    public function uploads(){
        $pageConfigs = [
            'pageHeader' => true
        ];

        return view('pages.user.uploads_new', [
            'pageConfigs' => $pageConfigs
        ]);
    }

    public function userloans(){
        $pageConfigs = [
            'pageHeader' => true
        ];
        $user_id = Auth::user()->id;
        $personal_data = PersonalInfo::where('user_id', $user_id)->first(); 
        $level = $personal_data->level;
        
        $ceiling = LoanCeiling::where('grade_level', $level)->first();
        $countLoan = LoanApplication::where('user_id', $user_id)->count();
        return view('pages.user.userloans', [
            'pageConfigs' => $pageConfigs,
            'countLoan' => $countLoan,
            'ceiling' => $ceiling
        ]);
    }

    public function loan_application(){
        $pageConfigs = [
            'pageHeader' => true
        ];
       
        $user_id = Auth::user()->id;
        
        $loan_types = LoanType::all();

        return view('pages.user.loan_application', [
            'pageConfigs' => $pageConfigs,
            'loan_types' => $loan_types,
            'ceiling' => $ceiling
        ]);
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
