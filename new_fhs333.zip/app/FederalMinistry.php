<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FederalMinistry extends Model
{
    //
}
