<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppointmentRecordData extends Model
{
    //
}
