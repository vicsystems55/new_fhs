<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoanCeiling extends Model
{
    //
}
