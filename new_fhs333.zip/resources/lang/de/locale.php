<?php

return [
  "Dashboard" => "Instrumententafel",
  "Starter kit" => "Starter-Kit",
  "2 Columns" => "2 Spalten",
  "Fixed Navbar" => "Navbar behoben",
  "Floating Navbar" => "Schwimmende Navbar",
  "Fixed Layout" => "Festes Layout",
  "Raise Support" => "Unterstützung erhöhen",
  "Documentation" => "Dokumentation"
];