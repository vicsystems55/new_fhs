<?php

return [
  "Dashboard" => "painel de controle",
  "Starter kit" => "Kit iniciante",
  "2 Columns" => "2 Colunas",
  "Fixed Navbar" => "Fixed Navbar",
  "Floating Navbar" => "Barra de navegação flutuante",
  "Fixed Layout" => "Layout fixo",
  "Raise Support" => "Levantar suporte",
  "Documentation" => "Documentação"
];