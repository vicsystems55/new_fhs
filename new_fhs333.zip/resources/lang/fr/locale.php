<?php

return [
  "Dashboard" => "Tableau de bord",
  "Starter kit" => "Kit de démarrage",
  "2 Columns" => "2 colonnes",
  "Fixed Navbar" => "Barre de navigation fixe",
  "Floating Navbar" => "Navbar flottant",
  "Fixed Layout" => "Disposition fixe",
  "Raise Support" => "Augmenter le soutien",
  "Documentation" => "Documentation"
];