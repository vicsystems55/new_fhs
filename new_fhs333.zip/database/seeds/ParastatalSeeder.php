<?php

use Illuminate\Database\Seeder;

class ParastatalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
